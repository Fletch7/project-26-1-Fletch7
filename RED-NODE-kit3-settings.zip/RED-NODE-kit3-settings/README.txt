SvelteKit 3.1 version of the settings page (font size slider)

Copy these files over the same paths inside your RED-NODE folder
(keep the folder structure), then:

  1. Delete node_modules and package-lock.json
  2. npm install
  3. npm run dev   (restart it - package.json "imports" is only read at startup)

Files:
  package.json                          (adds "imports" for #lib, Kit ^3.1.0, adapter-auto ^8)
  src/routes/settings/+page.svelte      (NEW settings page with slider)
  src/routes/+layout.svelte             (#lib imports, $app/env, $fontSize fix)
  src/lib/components/Header.svelte      (#lib, $app/state)
  src/lib/components/Footer.svelte      (Settings button -> /settings, $app/state)
  src/lib/stores/fontSize.js            ($app/env)
