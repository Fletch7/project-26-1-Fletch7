<script>
	import Header from '#lib/components/Header.svelte';
	import Footer from '#lib/components/Footer.svelte';
	import { fontSize } from '#lib/stores/fontSize';
	import { browser } from '$app/env';

	let { children } = $props();

	$effect (() => {
		if (browser) {
			document.documentElement.style.fontSize = `${$fontSize}px`;
		}
	});

</script>

<svelte:head>
	
</svelte:head>

<div class="layout">
	<Header />
	<main>
		{@render children()}
	</main>
	<Footer />
</div>

<style>	
	:global(body) {
		font-family: Arial, Helvetica, sans-serif;
		/* background-color: #eff1f1; */
		background-color: #F8F8F8;
		margin: 0;
		padding: 0;
		height: 100%;
	}

	.layout {
		display: flex;
		flex-direction: column;
		min-height: 100vh;
	}

	main {
		flex: 1;
		padding: 1rem;
		box-sizing: border-box;
	}

</style>
