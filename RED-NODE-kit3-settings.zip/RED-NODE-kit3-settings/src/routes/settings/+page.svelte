<script>
	import { fontSize } from '#lib/stores/fontSize';

	const MIN = 12;
	const MAX = 28;
	const DEFAULT = 16;
</script>

<svelte:head>
	<title>Settings | Kit Management</title>
</svelte:head>

<div class="page">
	<h1>Settings</h1>

	<section class="card">
		<label for="font-size">Text size: <strong>{$fontSize}px</strong></label>

		<input
			id="font-size"
			type="range"
			min={MIN}
			max={MAX}
			step="1"
			bind:value={$fontSize}
		/>

		<div class="scale" aria-hidden="true">
			<span>A</span>
			<span class="big">A</span>
		</div>

		<p class="preview">The quick brown fox jumps over the lazy dog.</p>

		<button type="button" onclick={() => ($fontSize = DEFAULT)} disabled={$fontSize === DEFAULT}>
			Reset to default ({DEFAULT}px)
		</button>

		<p class="note">Your choice applies to the whole site and is kept until you close this tab.</p>
	</section>
</div>

<style>
	.page {
		max-width: 40rem;
		margin: 0 auto;
	}

	.card {
		display: flex;
		flex-direction: column;
		gap: 1rem;
		padding: 1.5rem;
		background: #c4c4c4;
		border-radius: 1rem;
		color: #000;
	}

	label {
		font-size: 1.25rem;
	}

	input[type='range'] {
		width: 100%;
		accent-color: #01509f;
		cursor: pointer;
	}

	.scale {
		display: flex;
		justify-content: space-between;
		align-items: baseline;
		font-weight: 700;
		margin-top: -0.5rem;
	}

	.big {
		font-size: 1.75rem;
	}

	.preview {
		margin: 0;
		padding: 1rem;
		background: #fff;
		border-radius: 0.5rem;
	}

	button {
		align-self: flex-start;
		padding: 0.5rem 1rem;
		background: #01509f;
		color: #fff;
		border: none;
		border-radius: 1rem;
		font-size: 1rem;
		cursor: pointer;
	}

	button:disabled {
		background: #383838;
		cursor: default;
		opacity: 0.6;
	}

	.note {
		margin: 0;
		font-size: 0.875rem;
	}
</style>
