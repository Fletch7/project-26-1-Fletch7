<script>
	import { page } from '$app/state';
	import logo from '#lib/assets/polyechlogo.png';


	const links = [
		{ href: '/', text: 'Home' },
		{ href: '/report', text: 'Open Ticket' },
		{ href: '/login', text: 'Login' }
	];

	let currentPage = $derived.by(() => {
		const segments = page.url.pathname.split('/').filter(Boolean);
		if (segments.length === 0) return 'Home';

		const name = segments[segments.length - 1].replace(/[-_]/g, ' ');
		return name.charAt(0).toUpperCase() + name.slice(1);
	})
</script>

<header>
	<div class="left-section">
		<a href="/" class="brand">
			<img src={logo} alt="Logo" />
		</a>
	</div>

	<div class="middle-section">
		<h1>Otago Polytech | KIT Management</h1>
	</div>

	<div class="right-section">
		<span class="current-page"><h2>{currentPage}</h2></span>
	</div>
</header>

<style>
    header {
		display: grid;
		grid-template-columns: minmax(0, 1fr) auto minmax(0, 1fr);
		align-items: center;
		padding: 0.5rem 1rem;
		border-bottom: 1px solid #e5e5e5;
		background: #fff;
		
	}
	.right-section {
		margin-left: 400px;
	}

	nav {
		display: flex;
		align-items: center;
		justify-content: space-between;
		max-width: 60rem;
		margin: 0 auto;
		padding: 1rem;
	}

	.brand {
		font-weight: 700;
		font-size: 2rem;
		text-decoration: none;
		color: inherit;
	}

	ul {
		display: flex;
		gap: 1.5rem;
		margin: 0;
		padding: 0;
		list-style: none;
	}

	ul a {
		text-decoration: none;
		color: #555;
	}

</style>