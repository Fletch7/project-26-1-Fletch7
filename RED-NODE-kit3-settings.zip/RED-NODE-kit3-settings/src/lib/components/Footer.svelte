<script>
    import { page } from '$app/state'; 

    const links = [
        {href: '/settings', text: 'Settings'},
    ]
</script>

<footer>
    <foot class='brand' href="/">All rights reserved</foot>
    <nav>
        <ol>
            {#each links as { href, text }}
                <ol>
                    <a class="dashboard-button" {href} aria-current={page.url.pathname === href ? 'page' : undefined}>
                        {text}
                    </a>
                </ol>
            {/each}
        </ol>
    </nav>
</footer>

<style>
    .brand {
        font-weight: 700;
        font-size: 1rem;
        padding-left: 1rem;
        text-decoration: none;
        color: inherit;
    }
    footer {
		display: flex;
		justify-content: flex-start;
		align-items: center;
		border-bottom: 1px solid #e5e5e5;
		background: #fff;
    }
    .dashboard-button {
		display: grid;
		text-align: center;
		padding: 0.5rem 1rem;
		background-color: #01509F;
		color: white;
		text-decoration: none;
		border-radius: 1rem;
		font-size: 2rem;
		margin: 0;
		margin-top: 1rem;
		margin-left: 92rem;
		margin-right: 2rem;
	}
</style>